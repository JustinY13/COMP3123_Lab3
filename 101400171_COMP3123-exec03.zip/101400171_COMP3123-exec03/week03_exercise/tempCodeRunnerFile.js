var http = require("http");
//TODO - Use Employee Module here
console.log("Lab 03 -  NodeJs");
var employees=require("./Employee.js");
console.log(employees);